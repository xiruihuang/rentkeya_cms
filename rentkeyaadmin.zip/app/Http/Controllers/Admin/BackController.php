<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;

/**
 * 管理后台共用控制器
 * CommonController
 *
 * @author raoyc <raoyc2009@gmail.com>
 */
class BackController extends Controller
{

    public function __construct()
    {
    }
}
