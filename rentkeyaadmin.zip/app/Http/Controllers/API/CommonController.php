<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;

/**
 * [API站点]通用控制器
 * CommonController
 *
 * @author raoyc <raoyc2009@gmail.com>
 */
class CommonController extends Controller
{

    public function __construct()
    {

    }

}
