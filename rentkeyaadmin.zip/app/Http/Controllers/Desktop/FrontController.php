<?php

namespace App\Http\Controllers\Desktop;

use App\Http\Controllers\Controller;

/**
 * 桌面站点前台共用控制器
 * FrontController
 *
 * @author raoyc <raoyc2009@gmail.com>
 */
class FrontController extends Controller
{

    public function __construct()
    {
    }
}
