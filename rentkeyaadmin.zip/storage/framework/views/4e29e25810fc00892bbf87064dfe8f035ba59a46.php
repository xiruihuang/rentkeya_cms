<?php $__env->startSection('content-header'); ?>
@parent
          <h1>
            系统管理
            <small>系统日志</small>
          </h1>
          <ol class="breadcrumb">
            <li><a href="<?php echo e(site_url('dashboard', 'admin')); ?>"><i class="fa fa-dashboard"></i> 主页</a></li>
            <li class="active">系统管理 - 系统日志</li>
          </ol>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

              <?php if(session()->has('message')): ?>
                <div class="alert alert-success alert-dismissable">
                  <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                  <h4>  <i class="icon fa fa-check"></i> 提示！</h4>
                  <?php echo e(session('message')); ?>

                </div>
              <?php endif; ?>

              <div class="box box-primary">
                <div class="box-header with-border">
                  <h3 class="box-title">日志列表</h3>
                  <?php if (app('Illuminate\Contracts\Auth\Access\Gate')->check('log-search')): ?>
                  <div class="box-tools">
                    <form action="<?php echo e(_route('admin:log.index')); ?>" method="get" class="form-inline">

                      <div class="form-group">
                        <select data-placeholder="选择类型 ..." class="form-control input-sm chosen-select" name="type">
                          <option value="">选择类型</option>
                        <?php foreach(dict('log_type') as $k => $v): ?>
                          <option value="<?php echo e($k); ?>" <?php echo e((request('type') == $k) ? 'selected' : ''); ?>><?php echo e($v); ?></option>
                        <?php endforeach; ?>
                        </select>
                      </div>

                      <div class="form-group">
                        <input type="text" class="form-control input-sm pull-right" name="s_operator_realname" value="<?php echo e(request('s_operator_realname')); ?>" style="width: 150px;" placeholder="搜索操作者真实姓名">
                      </div>

                      <div class="form-group">
                        <input type="text" class="form-control input-sm pull-right" name="s_operator_ip" value="<?php echo e(request('s_operator_ip')); ?>" style="width: 150px;" placeholder="搜索操作者IP">
                      </div>

                      <button class="btn btn-sm btn-default"><i class="fa fa-search"></i></button>

                    </form>
                  </div>
                  <?php endif; ?>
                </div><!-- /.box-header -->
                <div class="box-body table-responsive">
                  <div class="tablebox-controls">
                    <button class="btn btn-default btn-sm"><i class="fa fa-file-excel-o" title="导出为excel文件"></i></button>
                    <button class="btn btn-default btn-sm"><i class="fa fa-file-text-o" title="导出为log文本文件"></i></button>                  </div>
                  <table class="table table-hover table-bordered">
                    <tbody>
                      <!--tr-th start-->
                      <tr>
                        <th>查阅</th>
                        <th>类型</th>
                        <th>操作者</th>
                        <th>操作者IP</th>
                        <th>操作URL</th>
                        <th>操作内容</th>
                        <th>操作时间</th>
                      </tr>
                      <!--tr-th end-->

                      <?php foreach($system_logs as $sys_log): ?>
                      <tr>
                        <td>
                            <?php if (app('Illuminate\Contracts\Auth\Access\Gate')->check('log-show')): ?>
                            <a href="<?php echo e(_route('admin:log.show', $sys_log->id)); ?>" class="layer_open" data-title="查看" data-width="400"><i class="fa fa-fw fa-link" title="查看"></i></a>
                            <?php endif; ?>
                        </td>
                        <td class="text-red"><?php echo e(dict('log_type.'.$sys_log->type)); ?></td>
                        <td class="text-green"><?php echo e(isset($sys_log->username) ? $sys_log->username : '--'); ?> / <?php echo e(isset($sys_log->realname) ? $sys_log->realname : '--'); ?></td>
                        <td class="text-yellow"><?php echo e($sys_log->operator_ip); ?></td>
                        <td class="overflow-hidden" title="<?php echo e($sys_log->url); ?>"><?php echo e($sys_log->url); ?></td>
                         <td class="overflow-hidden" title="<?php echo e($sys_log->content); ?>"><?php echo e(str_limit($sys_log->content, 70, '...')); ?></td>
                        <td><?php echo e($sys_log->created_at); ?></td>
                      </tr>
                      <?php endforeach; ?>

                    </tbody>
                  </table>
                </div><!-- /.box-body -->
                <div class="box-footer clearfix">
                  <?php echo $system_logs->appends([
                        'type' => request('type'),
                        's_operator_realname' => request('s_operator_realname'),
                        's_operator_ip' => request('s_operator_ip'),
                      ])->render();; ?>

                </div>

              </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('extraPlugin'); ?>
  <!--引入layer插件-->
  <script src="<?php echo e(_asset(ref('layer.js'))); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('filledScript'); ?>

        $('a.layer_open').on('click', function(evt){
            evt.preventDefault();
            var that = this;
            var src = $(this).attr("href");
            var title = $(this).data('title');
            layer.tips('这是你当前查看的日志', that);
            layer.open({
                type: 2,
                title: title,
                shadeClose: false,
                shade: 0,
                area: ['600px', '360px'],
                content: src //iframe的url
            });
        });

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout._back', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>