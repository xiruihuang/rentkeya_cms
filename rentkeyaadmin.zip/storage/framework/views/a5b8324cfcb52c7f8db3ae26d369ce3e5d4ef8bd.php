<?php $__env->startSection('mainContent'); ?>
        <div class="article">
            <div class="art_head">
                <h2><?php echo e($article->title); ?></h2>
            </div>
            <div class="art_meta clearfix">
                <span class="icon-folder"></span> <a href="<?php echo e(slug_url($article->category->slug)); ?>" title="查看“<?php echo e($article->category->name); ?>”分类下文章"><?php echo e($article->category->name); ?></a>    <span class="icon-calendar"></span> <a href="javascript:void(0);"><?php echo e($article->created_at->format('Y-m-d')); ?></a>
            </div>
            <div class="art_con">
            <?php echo mark2html($article->content); ?>

            </div>
        </div>
                        <?php
                            $_url = slug_url($article->category->slug, $article->slug, false);
                        ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('desktop.layout._base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>