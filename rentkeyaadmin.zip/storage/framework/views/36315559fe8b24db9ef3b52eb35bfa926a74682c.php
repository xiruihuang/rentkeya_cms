<?php $__env->startSection('content-header'); ?>
@parent
          <h1>
            用户管理
            <small>管理员</small>
          </h1>
          <ol class="breadcrumb">
            <li><a href="<?php echo e(site_url('dashboard', 'admin')); ?>"><i class="fa fa-dashboard"></i> 主页</a></li>
            <li><a href="<?php echo e(_route('admin:user.index')); ?>">用户管理 - 管理员</a></li>
            <li class="active">修改管理员</li>
          </ol>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

            <?php if(session()->has('fail')): ?>
              <div class="alert alert-success alert-dismissable">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <h4>  <i class="icon fa fa-check"></i> 提示！</h4>
                <?php echo e(session('fail')); ?>

              </div>
            <?php endif; ?>

            <?php if($errors->any()): ?>
              <div class="alert alert-danger alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <h4><i class="icon fa fa-ban"></i> 警告！</h4>
                    <ul>
                      <?php foreach($errors->all() as $error): ?>
                      <li><?php echo e($error); ?></li>
                      <?php endforeach; ?>
                    </ul>
              </div>
            <?php endif; ?>

              <div class="box box-primary">

                <div class="box-header with-border">
                  <h3 class="box-title">修改管理员资料</h3>
                  <p>以下展示ID为1 的管理员个人资料，您可修改昵称、真实姓名与登录密码等信息。登录密码项留空，则不修改登录密码。</p>
                  <div class="basic_info bg-info">
                     <ul>
                        <li>登录名：<span class="text-primary"><?php echo e($user->username); ?></span></li>
                        <li>昵称：<span class="text-primary"><?php echo e($user->nickname); ?></span></li>
                        <li>真实姓名：<span class="text-primary"><?php echo e($user->realname); ?></span></li>
                        <li>电子邮件：<span class="text-primary"><?php echo e($user->email); ?></span></li>
                        <li>手机号码：<b><?php echo e($user->phone); ?></b></li>
                    </ul>
                  </div>
                </div><!-- /.box-header -->

                <form method="post" action="<?php echo e(_route('admin:user.update', $user->id)); ?>" accept-charset="utf-8">
                <?php echo method_field('put'); ?>

                <?php echo csrf_field(); ?>

                  <div class="box-body">
                    <div class="form-group">
                      <label>昵称 <small class="text-red">*</small></label>
                      <input type="text" class="form-control" name="nickname" value="<?php echo e(old('nickname', isset($user) ? $user->nickname : null)); ?>" placeholder="昵称">
                    </div>
                    <div class="form-group">
                      <label>真实姓名 <small class="text-red">*</small></label>
                      <input type="text" class="form-control" name="realname" autocomplete="off" value="<?php echo e(old('realname', isset($user) ? $user->realname : null)); ?>" placeholder="真实姓名">
                    </div>

                    <div class="form-group">
                      <label>用户状态：是否锁定 <small class="text-red">*</small></label>
                      <div class="input-group">
                        <input type="radio" name="is_locked" value="0" <?php echo e(($user->is_locked === 0) ? 'checked' : ''); ?>>
                        <label class="choice" for="radiogroup">否</label>
                        <input type="radio" name="is_locked" value="1" <?php echo e(($user->is_locked === 1) ? 'checked' : ''); ?>>
                        <label class="choice" for="radiogroup">是</label>
                      </div>
                    </div>
                    <div class="form-group">
                      <label>角色(用户组) <small class="text-red">*</small></label>
                      <div class="input-group">
                          <select data-placeholder="选择角色..." class="chosen-select" style="min-width:200px;" name="role">
                          <?php foreach($roles as $role): ?>
                            <option value="<?php echo e($role->id); ?>" <?php echo e(($own_role->id === $role->id) ? 'selected':''); ?>><?php echo e($role->name); ?>(<?php echo e($role->display_name); ?>)</option>
                          <?php endforeach; ?>
                        </select>
                      </div>
                    </div>
                    <div class="form-group">
                      <label>登录密码</label>
                      <input type="password" class="form-control" name="password" value="" autocomplete="off" placeholder="登录密码">
                    </div>
                    <div class="form-group">
                      <label>确认登录密码</label>
                      <input type="password" class="form-control" name="password_confirmation" value="" autocomplete="off" placeholder="登录密码">
                    </div>
                  </div><!-- /.box-body -->

                  <div class="box-footer">
                    <button type="submit" class="btn btn-primary">修改个人资料</button>
                  </div>
                </form>

              </div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('extraPlugin'); ?>

  <!--引入iCheck组件-->
  <script src="<?php echo e(_asset(ref('icheck.js'))); ?>" type="text/javascript"></script>
  <!--引入Chosen组件-->
  <?php echo $__env->make('admin.scripts.endChosen', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('filledScript'); ?>
        <!--启用iCheck响应checkbox与radio表单控件-->
        $('input[name="is_locked"]').iCheck({
          radioClass: 'iradio_flat-blue',
          increaseArea: '20%' // optional
        });
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout._back', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>