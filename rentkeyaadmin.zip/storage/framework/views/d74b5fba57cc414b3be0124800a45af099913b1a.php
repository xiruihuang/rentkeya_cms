<?php $__env->startSection('hacker_header'); ?>
<?php echo $__env->yieldSection(); ?><?php /* 黑客头部申明区域 */ ?>

<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <title><?php $__env->startSection('title'); ?> Rentkeya <?php echo $__env->yieldSection(); ?><?php /* 页面标题 */ ?></title>
    <meta name="description" content="<?php echo e(isset($description) ? $description : 'Rentkeya'); ?>" />
    <meta name="keywords" content="Rentkeya,<?php echo e(cache('website_keywords')); ?>" />
    <meta name="author" content=Rentkeya,"<?php echo e(cache('system_author_website')); ?>" />
    <meta name="renderer" content="webkit"><?php /* 360浏览器使用webkit内核渲染页面 */ ?>
    <meta http-equiv="X-UA-Compatible" content="IE=Edge,chrome=1" /><?php /* IE(内核)浏览器优先使用高版本内核 */ ?>

    <?php $__env->startSection('meta'); ?>
    <?php echo $__env->yieldSection(); ?><?php /* 添加一些额外的META申明 */ ?>
    <link rel="shortcut icon" href="<?php echo e(_asset('favicon.ico')); ?>" type="image/x-icon"><?php /* favicon */ ?>

    <?php $__env->startSection('head_css'); ?>
    <?php echo $__env->yieldSection(); ?><?php /* head区域css样式表 */ ?>

    <?php $__env->startSection('head_js'); ?>
    <?php echo $__env->yieldSection(); ?><?php /* head区域javscript脚本 */ ?>

    <?php $__env->startSection('beforeStyle'); ?>
    <?php echo $__env->yieldSection(); ?><?php /* 在内联样式之前填充一些东西 */ ?>

    <?php $__env->startSection('head_style'); ?>
    <?php echo $__env->yieldSection(); ?><?php /* head区域内联css样式表 */ ?>

    <?php $__env->startSection('afterStyle'); ?>
    <?php echo $__env->yieldSection(); ?><?php /* 在内联样式之后填充一些东西 */ ?>

</head>
<body <?php $__env->startSection('body_attr'); ?>class=""<?php echo $__env->yieldSection(); ?><?php /* 追加类属性 */ ?>>

    <?php $__env->startSection('beforeBody'); ?>
    <?php echo $__env->yieldSection(); ?><?php /*在正文之后填充一些东西 */ ?>

    <?php $__env->startSection('body'); ?>
    <?php echo $__env->yieldSection(); ?><?php /* 正文部分 */ ?>

    <?php $__env->startSection('afterBody'); ?>
    <?php echo $__env->yieldSection(); ?><?php /* 在正文之后填充一些东西，比如统计代码之类的东东 */ ?>

</body>
</html>

<?php $__env->startSection('hacker_footer'); ?>
<?php echo $__env->yieldSection(); ?><?php /* 黑客尾部申明区域 */ ?>
