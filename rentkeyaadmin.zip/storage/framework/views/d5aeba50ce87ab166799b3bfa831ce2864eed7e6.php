<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <title>Rentkeya员工管理</title>
    <meta name="description" content="<?php $__env->startSection('description'); ?> <?php echo e(isset($description) ? $description : 'Rentkeya员工管理日志!'); ?> <?php echo $__env->yieldSection(); ?><?php /* meta描述 */ ?>" />
    <meta name="keywords" content="管理系统,<?php echo e(cache('website_keywords')); ?>" />
    <meta name="author" content="<?php echo e(cache('system_author_website', 'rentkeya.com')); ?>" />
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=Edge,chrome=1" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <link rel="stylesheet" href="<?php echo e(_asset('assets/css/style.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(_asset('assets/css/icomoon_style.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(_asset('assets/css/markdown_style.css')); ?>" />
    <?php $__env->startSection('htmlHead'); ?>
    <?php echo $__env->yieldSection(); ?><?php /* head区域 */ ?>
</head>
<body class="paper">


<div id="con_wrapper">
    <div id="r_con">
        <div class="header">
            <a href="/"><h1>Rentkeya员工管理</h1></a>
        </div>
        
        <?php $__env->startSection('mainContent'); ?>
        <?php echo $__env->yieldSection(); ?><?php /* 主体内容 */ ?>

        <div class="footer">
            <a href="/"><h1>请尽快完成tasks</h1></a>
        </div>

    </div>
</div>

<?php $__env->startSection('afterFooter'); ?>

<?php echo $__env->yieldSection(); ?><?php /* 页脚区域 */ ?>
</body>
</html>
