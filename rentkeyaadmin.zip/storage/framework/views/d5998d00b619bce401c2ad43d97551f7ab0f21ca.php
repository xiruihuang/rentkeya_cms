<?php /* 分页样式 */ ?>
<?php echo e(with(new Douyasi\Extensions\SimpleBootstrapThreePreviousNextPresenter($paginator))->render()); ?>

