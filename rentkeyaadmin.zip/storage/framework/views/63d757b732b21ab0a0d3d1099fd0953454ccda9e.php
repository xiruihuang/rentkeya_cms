<?php $__env->startSection('content-header'); ?>
@parent
          <h1>
            内容管理
            <small>文章</small>
          </h1>
          <ol class="breadcrumb">
            <li><a href="<?php echo e(site_url('dashboard', 'admin')); ?>"><i class="fa fa-dashboard"></i> 主页</a></li>
            <li class="active">内容管理 - 文章</li>
          </ol>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

              <?php if(session()->has('message')): ?>
                <div class="alert alert-success alert-dismissable">
                  <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                  <h4>  <i class="icon fa fa-check"></i> 提示！</h4>
                  <?php echo e(session('message')); ?>

                </div>
              <?php endif; ?>

              <a href="<?php echo e(_route('admin:article.create')); ?>" class="btn btn-primary margin-bottom">撰写新文章</a>

              <div class="box box-primary">
                <div class="box-header with-border">
                  <h3 class="box-title">文章列表</h3>
                  <?php if (app('Illuminate\Contracts\Auth\Access\Gate')->check('article-search')): ?>
                  <div class="box-tools">
                    <form action="<?php echo e(_route('admin:article.index')); ?>" method="get">
                      <div class="input-group">
                        <input type="text" class="form-control input-sm pull-right" name="s_title" value="<?php echo e(request('s_title')); ?>" style="width: 150px;" placeholder="搜索文章标题">
                        <div class="input-group-btn">
                          <button class="btn btn-sm btn-default"><i class="fa fa-search"></i></button>
                        </div>
                      </div>
                    </form>
                  </div>
                  <?php endif; ?>
                </div><!-- /.box-header -->
                <div class="box-body table-responsive">
                  <table class="table table-hover table-bordered">
                    <tbody>
                      <!--tr-th start-->
                      <tr>
                        <th>操作</th>
                        <th>推荐位</th>
                        <th>标题</th>
                        <th>slug</th>
                        <th>缩略图</th>
                        <th>分类</th>
                        <th>更新时间</th>
                      </tr>
                      <!--tr-th end-->

                      <?php foreach($articles as $art): ?>
                      <tr>
                        <td>
                            <?php if (app('Illuminate\Contracts\Auth\Access\Gate')->check('article-write')): ?>
                            <a href="<?php echo e(_route('admin:article.edit', $art->id)); ?>"><i class="fa fa-fw fa-pencil" title="修改"></i></a>
                            <?php endif; ?>
                            <a href="javascript:void(0);"><i class="fa fa-fw fa-link" title="预览"></i></a>
                        </td>
                        <td class="text-green"><?php echo flag_tag($art->flag, $flags); ?></td>
                        <td class="text-muted" title="<?php echo e($art->title); ?>"><?php echo e(str_limit($art->title, 36)); ?></td>
                        <td title="//example.org/{category}/<?php echo e($art->slug); ?>.html"><span class="text-red"><?php echo e(str_limit($art->slug, 16)); ?></span></td>
                        <td class="text-green">
                          <?php if(empty($art->thumb)): ?>
                              -
                          <?php else: ?>
                              <a href="<?php echo e($art->thumb); ?>" class="layer_open"><?php echo e(str_limit($art->thumb, 30)); ?></a>
                          <?php endif; ?>
                        </td>
                        <td class="text-red"><a href="<?php echo e(_route('admin:article.index', ['s_cid' => $art->cid] )); ?>"><?php echo e($art->category->name); ?></a></td>
                        <td><?php echo e($art->updated_at); ?></td>
                      </tr>
                      <?php endforeach; ?>

                    </tbody>
                  </table>
                </div><!-- /.box-body -->
                <div class="box-footer clearfix">
                  <?php echo $articles->appends([
                                          's_cid' => request('s_cid'),
                                          's_title' => request('s_title'),
                                        ])->render(); ?>

                </div>

              </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('extraPlugin'); ?>
  <!--引入layer插件-->
  <script src="<?php echo e(_asset(ref('layer.js'))); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('filledScript'); ?>

        $('a.layer_open').on('click', function(evt){
            evt.preventDefault();
            var src = $(this).attr("href");
            var title = $(this).data('title');
            var width = $(window).width();
            if(width > 1080) {
                width = 1080
            } else {
                width = 980;
            }
            layer.open({
                type: 2,
                title: title,
                shadeClose: false,
                shade: 0.8,
                area: [ width+'px', '90%'],
                content: src //iframe的url
            });
        });

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout._back', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>