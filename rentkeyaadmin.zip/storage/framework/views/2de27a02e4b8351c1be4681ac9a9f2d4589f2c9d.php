      <?php /* widget.main-sidebar */ ?>

      <!-- Left side column. contains the logo and sidebar -->
      <aside class="main-sidebar">

        <!-- sidebar: style can be found in sidebar.less -->
        <section class="sidebar">

          <!-- Sidebar user panel (optional) -->
          <div class="user-panel">
            <div class="pull-left image">
              <img src="<?php echo e(_asset('back/dist/img/20150417113714.jpg')); ?>" class="img-circle" alt="User Image" />
            </div>
            <div class="pull-left info">
              <p><?php echo e(auth()->user()->realname); ?></p>
              <!-- Status -->
              <a href="#"><i class="fa fa-circle text-success"></i> 在线</a>
            </div>
          </div>

          <!-- search form (Optional) -->
          <form action="#" method="get" class="sidebar-form">
            <div class="input-group">
              <input type="text" name="q" class="form-control" placeholder="搜索..."/>
              <span class="input-group-btn">
                <button type='submit' name='search' id='search-btn' class="btn btn-flat"><i class="fa fa-search"></i></button>
              </span>
            </div>
          </form>
          <!-- /.search form -->

          <!-- Sidebar Menu -->
          <ul class="sidebar-menu">
            <li class="header">主导航栏</li>

            <!--无子节点的一级导航节点-->
            <li><a href="<?php echo e(site_url('dashboard', 'admin')); ?>"><i class="fa fa-dashboard"></i> <span>控制台</span> </a></li>
            <li><a href="<?php echo e(site_url('cache', 'admin')); ?>"><i class="fa fa-eraser"></i> <span>重建缓存</span> </a></li>

            <!--自定义二次开发导航区域 START-->

            <?php foreach($menus = config('ecms.sidebar') as $menu): ?>
              <li class="treeview">
              <a href="#">
                <i class='fa <?php echo e($menu['icon']); ?>'></i>
                <span><?php echo e($menu['name']); ?></span>
                <i class="fa fa-angle-left pull-right"></i>
              </a>
              <ul class="treeview-menu">
              <?php foreach($sub_menus = $menu['sub_menu'] as $sub): ?>
                <?php if($sub['can'] !== ''): ?>
                  <?php if (app('Illuminate\Contracts\Auth\Access\Gate')->check($sub['can'])): ?>
                  <li><a href="<?php if(str_contains($sub['route'], '//')): ?><?php echo e($sub['route']); ?><?php else: ?><?php echo e(_route($sub['route'])); ?><?php endif; ?>" <?php if(str_contains($sub['route'], '//')): ?>target="_blank"<?php endif; ?>><i class="fa <?php echo e($menu['child_icon']); ?>"></i><?php echo e($sub['name']); ?></a></li>
                  <?php endif; ?>
                <?php else: ?>
                  <li><a href="<?php if(str_contains($sub['route'], '//')): ?><?php echo e($sub['route']); ?><?php else: ?><?php echo e(_route($sub['route'])); ?><?php endif; ?>" <?php if(str_contains($sub['route'], '//')): ?> target="_blank"<?php endif; ?>><i class="fa <?php echo e($menu['child_icon']); ?>"></i><?php echo e($sub['name']); ?></a></li>
                <?php endif; ?>
              <?php endforeach; ?>
              </ul>
            </li>
            <?php endforeach; ?>

            <!--自定义二次开发导航区域 END-->

            <!--用户管理 treeview-->
            <li class="treeview">
              <a href="#">
                <i class='fa fa-user-secret'></i>
                <span>用户管理</span>
                <i class="fa fa-angle-left pull-right"></i>
              </a>
              <ul class="treeview-menu">
                <?php if (app('Illuminate\Contracts\Auth\Access\Gate')->check('@me')): ?>
                <li><a href="<?php echo e(site_url('me', 'admin')); ?>"><i class="fa fa-circle-o"></i>个人资料</a></li>
                <?php endif; ?>
                <?php if (app('Illuminate\Contracts\Auth\Access\Gate')->check('@user')): ?>
                <li><a href="<?php echo e(site_url('user', 'admin')); ?>"><i class="fa fa-circle-o"></i>管理员(用户)</a></li>
                <?php endif; ?>
                <?php if (app('Illuminate\Contracts\Auth\Access\Gate')->check('@role')): ?>
                <li><a href="<?php echo e(site_url('role', 'admin')); ?>"><i class="fa fa-circle-o"></i>角色</a></li>
                <?php endif; ?>
                <?php if (app('Illuminate\Contracts\Auth\Access\Gate')->check('@permission')): ?>
                <li><a href="<?php echo e(site_url('permission', 'admin')); ?>"><i class="fa fa-circle-o"></i>权限</a></li>
                <?php endif; ?>
              </ul>
            </li>
            <!--//用户管理 treeview-->


            <!--系统管理 treeview-->
            <li class="treeview">
              <a href="#">
                <i class='fa fa-cog'></i>
                <span>系统管理</span>
                <i class="fa fa-angle-left pull-right"></i>
              </a>
              <ul class="treeview-menu">
                <?php if (app('Illuminate\Contracts\Auth\Access\Gate')->check('@option')): ?>
                <li><a href="<?php echo e(site_url('option', 'admin')); ?>"><i class="fa fa-square-o"></i>系统配置</a></li>
                <?php endif; ?>
                <?php if (app('Illuminate\Contracts\Auth\Access\Gate')->check('@log')): ?>
                <li><a href="<?php echo e(site_url('log', 'admin')); ?>"><i class="fa fa-square-o"></i>系统日志</a></li>
                <?php endif; ?>
              </ul>
            </li>
            <!--//系统管理 treeview-->

          </ul><!-- /.sidebar-menu -->
        </section>
        <!-- /.sidebar -->
      </aside>
