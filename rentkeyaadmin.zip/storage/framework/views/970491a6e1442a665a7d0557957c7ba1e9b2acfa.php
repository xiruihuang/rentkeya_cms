<?php $__env->startSection('title'); ?> Layer - YASCMF <?php $__env->stopSection(); ?>

<?php $__env->startSection('meta'); ?>
<meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('head_css'); ?>
    <link href="<?php echo e(_asset(ref('bootstrap.css'))); ?>" rel="stylesheet" type="text/css" />
    <!-- Theme style -->
    <link href="<?php echo e(_asset('back/dist/css/yascmf.css')); ?>" rel="stylesheet" type="text/css" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('head_js'); ?>
    <!--这里使用旧版jQuery-->
    <script type="text/javascript" src="<?php echo e(_asset(ref('jquery.js'))); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
    <div class="close_button"><?php /* 自定义关闭 按钮 */ ?>
        <a href="javascript:void(0);" class="avgrund-close">close</a>
    </div>
    <div class="yascmf_layer">
        <?php $__env->startSection('mainLayerCon'); ?>
        <?php echo $__env->yieldSection(); ?><?php /* layer表单页面主体内容 */ ?>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('afterBody'); ?>
@parent
    <?php $__env->startSection('endChosen'); ?>
    <?php echo $__env->yieldSection(); ?><?php /* chosen下拉选择表单 */ ?>
    <?php $__env->startSection('endLayerJS'); ?>
    <?php echo $__env->yieldSection(); ?><?php /* layer响应部分事件JS */ ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout._base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>