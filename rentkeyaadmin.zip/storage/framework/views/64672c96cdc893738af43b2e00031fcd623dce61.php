<?php $__env->startSection('content-header'); ?>
@parent
          <h1>
            内容管理
            <small>分类</small>
          </h1>
          <ol class="breadcrumb">
            <li><a href="<?php echo e(site_url('dashboard', 'admin')); ?>"><i class="fa fa-dashboard"></i> 主页</a></li>
            <li class="active">内容管理 - 分类</li>
          </ol>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

              <?php if(session()->has('fail')): ?>
                <div class="alert alert-warning alert-dismissable">
                  <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                  <h4>  <i class="icon icon fa fa-warning"></i> 提示！</h4>
                  <?php echo e(session('fail')); ?>

                </div>
              <?php endif; ?>

              <?php if(session()->has('message')): ?>
                <div class="alert alert-success alert-dismissable">
                  <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                  <h4>  <i class="icon fa fa-check"></i> 提示！</h4>
                  <?php echo e(session('message')); ?>

                </div>
              <?php endif; ?>

              <a href="<?php echo e(_route('admin:category.create')); ?>" class="btn btn-primary margin-bottom">新增分类</a>

              <div class="box box-primary">
                <div class="box-header with-border">
                  <h3 class="box-title">分类列表</h3>
                </div><!-- /.box-header -->
                <div class="box-body table-responsive">
                  <table class="table table-hover table-bordered">
                    <tbody>
                      <!--tr-th start-->
                      <tr>
                        <th>操作</th>
                        <th>编号</th>
                        <th>名称</th>
                        <th>缩略名</th>
                        <th>排序</th>
                        <th>更新时间</th>
                      </tr>
                      <!--tr-th end-->

                      <?php foreach($categories as $cat): ?>
                      <tr>
                        <td>
                            <?php if (app('Illuminate\Contracts\Auth\Access\Gate')->check('category-write')): ?>
                            <a href="<?php echo e(_route('admin:category.edit', $cat->id)); ?>"><i class="fa fa-fw fa-pencil" title="修改"></i></a>
                            <?php endif; ?>
                            <?php if (app('Illuminate\Contracts\Auth\Access\Gate')->check('category-show')): ?>
                            <a href="<?php echo e(_route('admin:article.index', ['s_cid' => $cat->id])); ?>"><i class="fa fa-fw fa-link" title="查看该分类下文章"></i></a>
                            <?php endif; ?>
                        </td>
                        <td><?php echo e($cat->id); ?></td>
                        <td class="text-muted">
                          <?php echo e($cat->name); ?>

                        </td>
                        <td class="text-green">
                          <?php if(empty($cat->slug)): ?>
                          -
                          <?php else: ?>
                          <?php echo e($cat->slug); ?>

                          <?php endif; ?>
                        </td>
                        <td><?php echo e($cat->sort); ?></td>
                        <td><?php echo e($cat->updated_at); ?></td>
                      </tr>
                      <?php endforeach; ?>

                    </tbody>
                  </table>
                </div><!-- /.box-body -->
                <div class="box-footer clearfix">
                  <?php echo $categories->render(); ?>

                </div>

              </div>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('admin.layout._back', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>