<?php $__env->startSection('hacker_header'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?> 后台 - Rentkeya <?php $__env->stopSection(); ?>

<?php $__env->startSection('meta'); ?>
<meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('head_css'); ?>
    <link href="<?php echo e(_asset(ref('bootstrap.css'))); ?>" rel="stylesheet" type="text/css" />
    <!-- Font Awesome Icons -->
    <link href="<?php echo e(_asset(ref('font-awesome.css'))); ?>" rel="stylesheet" type="text/css" />
    <!-- Ionicons -->
    <link href="<?php echo e(_asset(ref('ionicons.css'))); ?>" rel="stylesheet" type="text/css" />
    <!-- Theme style -->
    <link href="<?php echo e(_asset('back/dist/css/yascmf.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(_asset('back/dist/css/skins/_all-skins.min.css')); ?>" rel="stylesheet" type="text/css" />
    <!--
    <link href="<?php echo e(_asset('back/dist/css/skins/skin-black.min.css')); ?>" rel="stylesheet" type="text/css" />
    -->
    <link href="<?php echo e(_asset(ref('icheck_all.css'))); ?>" rel="stylesheet" type="text/css" />

<?php $__env->stopSection(); ?>

<?php $__env->startSection('head_js'); ?>
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="<?php echo e(_asset(ref('html5shiv.js'))); ?>"></script>
        <script src="<?php echo e(_asset(ref('respond.js'))); ?>"></script>
    <![endif]-->
@parent
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body_attr'); ?> class="skin-black sidebar-mini"<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>

<!--侦测是否启用JavaScript脚本-->
<noscript>
<style type="text/css">
.noscript{ width:100%;height:100%;overflow:hidden;background:#000;color:#fff;position:absolute;z-index:99999999; background-color:#000;opacity:1.0;filter:alpha(opacity=100);margin:0 auto;top:0;left:0;}
.noscript h1{font-size:36px;margin-top:50px;text-align:center;line-height:40px;}
html {overflow-x:hidden;overflow-y:hidden;}/*禁止出现滚动条*/
</style>
<div class="noscript">
<h1>
您的浏览器不支持JavaScript，请启用后重试！
</h1>
</div>
</noscript>

<!--wrapper start-->
    <div class="wrapper">

      <?php echo $__env->make('admin.widgets.main-header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

      <?php echo $__env->make('admin.widgets.main-sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">

          <?php $__env->startSection('content-header'); ?>
          <?php echo $__env->yieldSection(); ?><?php /* 内容导航头部 */ ?>

        </section>

        <!-- Main content -->
        <section class="content">

          <?php $__env->startSection('content'); ?>
          <?php echo $__env->yieldSection(); ?><?php /* 内容主体区域 */ ?>

        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->

      <!-- Main Footer -->
      <footer class="main-footer">
        <!-- To the right -->
        <div class="pull-right hidden-xs">
          后台模版基于 <a href="https://github.com/almasaeed2010/AdminLTE">AdminLTE</a> ， 经过 <a href="rentkeya.com">raymond Huang</a> 修改以适配当前系统 。
        </div>
        <!-- Default to the left -->
      </footer>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('afterBody'); ?>
      <!-- Control Sidebar -->
      <aside class="control-sidebar control-sidebar-dark">

        <?php echo $__env->make('admin.widgets.control-sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

      </aside><!-- /.control-sidebar -->
      <!-- Add the sidebar's background. This div must be placed
           immediately after the control sidebar -->
      <div class='control-sidebar-bg'></div>
    </div><!-- ./wrapper -->

    <!-- REQUIRED JS SCRIPTS -->

    <!-- jQuery 2.1.3 -->
    <script src="<?php echo e(_asset(ref('jquery.js'))); ?>"></script>
    <!-- Bootstrap 3.3.2 JS -->
    <script src="<?php echo e(_asset(ref('bootstrap.js'))); ?>" type="text/javascript"></script>
    <!-- AdminLTE App -->
    <script src="<?php echo e(_asset('back/dist/js/app.min.js')); ?>" type="text/javascript"></script>

    <!-- Slimscroll -->
    <script src="<?php echo e(_asset('back/plugins/slimScroll/jquery.slimscroll.min.js')); ?>" type="text/javascript"></script>
    
    <?php $__env->startSection('extraPlugin'); ?>
    <?php echo $__env->yieldSection(); ?><?php /* 引入额外依赖JS插件 */ ?>

    
    <script type="text/javascript">
      $(document).ready(function(){
          <!--highlight main-sidebar-->
          /*导航高亮*/
          var path_array = window.location.pathname.split( '/' );
          var scheme_less_url = '//' + window.location.host + window.location.pathname;
          if(path_array[3] === undefined || path_array[3] === "create" || parseInt(path_array[3]) == path_array[3]) {
            <?php /*
            <!--
            排除 restful url
            /admin/article                   ["", "admin", "article"]
            /admin/article/create            ["", "admin", "article", "create"]
            /admin/article/8/edit            ["", "admin", "article", "8", "edit"]
            /admin/article/8                 ["", "admin", "article", "8"]
            -->
            */ ?>
            scheme_less_url = '//' + window.location.host + '/' + path_array[1] + '/' + path_array[2];
          }
          $('ul.treeview-menu>li').find('a[href="'+scheme_less_url+'"]').closest('li').addClass('active');  //二级链接高亮
          $('ul.treeview-menu>li').find('a[href="'+scheme_less_url+'"]').closest('li.treeview').addClass('active');  //一级栏目[含二级链接]高亮
          $('.sidebar-menu>li').find('a[href="'+scheme_less_url+'"]').closest('li').addClass('active');  //一级栏目[不含二级链接]高亮

          <?php $__env->startSection('filledScript'); ?>
          <?php echo $__env->yieldSection(); ?><?php /* 在document ready 里面填充一些JS代码 */ ?>
      });
    </script>
    <!-- AdminLTE for demo purposes -->
    <script src="<?php echo e(_asset('back/dist/js/yascmf.js')); ?>" type="text/javascript"></script>

    <!-- Optionally, you can add Slimscroll and FastClick plugins.
          Both of these plugins are recommended to enhance the
          user experience. Slimscroll is required when using the
          fixed layout. -->

      <?php $__env->startSection('extraSection'); ?>
      <?php echo $__env->yieldSection(); ?><?php /* 补充额外的一些东东，不一定是JS，可能是HTML */ ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('hacker_footer'); ?>

<!--
    ____                                   __   __             __                                __
   / __ \____ _      _____  ________  ____/ /  / /_  __  __   / /   ____ __________ __   _____  / /
  / /_/ / __ \ | /| / / _ \/ ___/ _ \/ __  /  / __ \/ / / /  / /   / __ `/ ___/ __ `/ | / / _ \/ / 
 / ____/ /_/ / |/ |/ /  __/ /  /  __/ /_/ /  / /_/ / /_/ /  / /___/ /_/ / /  / /_/ /| |/ /  __/ /  
/_/    \____/|__/|__/\___/_/   \___/\__,_/  /_.___/\__, /  /_____/\__,_/_/   \__,_/ |___/\___/_/   
                                                  /____/                                           


Powered by Laravel 
v5.2.x
-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout._base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>