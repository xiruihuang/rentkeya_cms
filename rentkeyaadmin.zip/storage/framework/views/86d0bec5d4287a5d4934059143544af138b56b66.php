<?php $__env->startSection('mainContent'); ?>
<div class="artlist_content">
<h2></h2>
            <div class="post_summary">
                <?php echo e($category->name); ?>分类下共有 <em class="text-info"><?php echo e($count); ?></em> 篇文章
            </div>
            <ul class="art_list">
                <?php foreach($articles as $art): ?>
                <li>
                    <h3><a href="<?php echo e(slug_url($art->category->slug, $art->slug)); ?>"><?php echo e($art->title); ?></a></h3>
                    <div class="art_desc">
                        <p><?php echo e($art->description); ?></p>
                    </div>
                    <div class="split_border"></div>
                </li>
                <?php endforeach; ?>
            </ul>
            <div class="page clearfix">
                <?php echo $__env->make('desktop.parts.pagination', ['paginator' => $articles], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('desktop.layout._base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>