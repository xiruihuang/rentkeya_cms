<?php $__env->startSection('content-header'); ?>
@parent
          <h1>
            用户管理
            <small>管理员</small>
          </h1>
          <ol class="breadcrumb">
            <li><a href="<?php echo e(site_url('dashboard', 'admin')); ?>"><i class="fa fa-dashboard"></i> 主页</a></li>
            <li class="active">用户管理 - 管理员</li>
          </ol>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

              <?php if(session()->has('message')): ?>
                <div class="alert alert-success alert-dismissable">
                  <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                  <h4>  <i class="icon fa fa-check"></i> 提示！</h4>
                  <?php echo e(session('message')); ?>

                </div>
              <?php endif; ?>

              <?php if (app('Illuminate\Contracts\Auth\Access\Gate')->check('user-write')): ?>
              <a href="<?php echo e(_route('admin:user.create')); ?>" class="btn btn-primary margin-bottom">新增管理员(用户)</a>
              <?php endif; ?>

              <div class="box box-primary">
                <div class="box-header with-border">
                  <h3 class="box-title">管理员列表</h3>
                  <?php if (app('Illuminate\Contracts\Auth\Access\Gate')->check('user-search')): ?>
                  <div class="box-tools">
                    <form action="<?php echo e(_route('admin:user.index')); ?>" method="get" class="form-inline">
                      <div class="form-group">
                        <input type="text" class="form-control input-sm" name="s_name" value="<?php echo e(request('s_name')); ?>" style="width: 200px;" placeholder="搜索用户登录名或昵称或真实姓名">
                      </div>
                      <div class="form-group">
                        <input type="text" class="form-control input-sm" name="s_phone" value="<?php echo e(request('s_phone')); ?>" style="width: 150px;" placeholder="搜索用户手机号">
                      </div>
                      <button class="btn btn-sm btn-default"><i class="fa fa-search"></i></button>
                    </form>
                  </div>
                  <?php endif; ?>
                </div><!-- /.box-header -->
                <div class="box-body table-responsive">
                  <table class="table table-hover table-bordered">
                    <tbody>
                      <!--tr-th start-->
                      <tr>
                        <th>操作</th>
                        <th>编号</th>
                        <th>登录名 / 昵称</th>
                        <th>真实姓名</th>
                        <th>角色</th>
                        <th>状态</th>
                        <th>最后一次登录时间</th>
                      </tr>
                      <!--tr-th end-->
                      <?php foreach($users as $user): ?>
                      <tr>
                        <td>
                          <?php if (app('Illuminate\Contracts\Auth\Access\Gate')->check('user-write')): ?>
                          <a href="<?php echo e(_route('admin:user.edit', $user->id)); ?>"><i class="fa fa-fw fa-pencil" title="修改"></i></a>
                          <?php endif; ?>
                        </td>
                        <td><?php echo e($user->id); ?></td>
                        <td class="text-muted"><?php echo e($user->username); ?> / <?php echo e($user->nickname); ?></td>
                        <td class="text-green">
                          <?php echo e($user->realname); ?>

                        </td>
                        <td class="text-red">
                          <?php if(null !== $user->roles->first()): ?>  <?php /* 某些错误情况下，会造成管理用户没有角色 */ ?>
                          <a class="layer_open" data-title="<?php echo e($user->username); ?> / <?php echo e($user->nickname); ?> 管理用户权限详情" href="<?php echo e(_route('admin:user.purview.show', $user->roles->first()->id)); ?>"><i class="fa fa-fw fa-info-circle" title="管理用户权限详情"></i></a>

                          <?php echo e($user->roles->first()->name); ?>(<?php echo e($user->roles->first()->display_name); ?>)
                          <?php else: ?>
                          NULL(空)
                          <?php endif; ?>
                        </td>
                        <td class="text-yellow">
                          <?php if($user->is_locked): ?>
                          锁定
                          <?php else: ?>
                          正常
                          <?php endif; ?>
                        </td>
                        <td><?php echo e($user->updated_at); ?></td>
                      </tr>
                      <?php endforeach; ?>
                    </tbody>
                  </table>
                </div><!-- /.box-body -->
                <div class="box-footer clearfix">
                  <?php echo $users->appends(['s_name' => request('s_name'), 's_phone' => request('s_phone')])->render(); ?>

                </div>

              </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('extraSection'); ?>
  <!--引入layer插件-->
  <script src="<?php echo e(_asset(ref('layer.js'))); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('filledScript'); ?>
        $('a.layer_open').on('click', function(evt){
            evt.preventDefault();
            var src = $(this).attr("href");
            var title = $(this).data('title');
            layer.open({
                type: 2,
                title: title,
                shadeClose: true,
                shade: 0.8,
                area: ['800px', '720px'],
                content: src //iframe的url
            });
        });
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout._back', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>