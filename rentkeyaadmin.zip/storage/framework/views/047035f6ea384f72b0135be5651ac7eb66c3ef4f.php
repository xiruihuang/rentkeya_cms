<?php $__env->startSection('content-header'); ?>
@parent
          <h1>
            用户管理
            <small>权限</small>
          </h1>
          <ol class="breadcrumb">
            <li><a href="<?php echo e(site_url('dashboard', 'admin')); ?>"><i class="fa fa-dashboard"></i> 主页</a></li>
            <li class="active">用户管理 - 权限</li>
          </ol>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

              <?php if(session()->has('message')): ?>
                <div class="alert alert-success alert-dismissable">
                  <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                  <h4>  <i class="icon fa fa-check"></i> 提示！</h4>
                  <?php echo e(session('message')); ?>

                </div>
              <?php endif; ?>

              <div class="box box-primary">
                <div class="box-header with-border">
                  <h3 class="box-title">权限列表</h3>
                  <div class="box-tips clearfix">
                    <p><b>权限影响系统安全与稳定，错误或不合理的修改可能会影响系统业务与逻辑，故在此屏蔽掉权限 增、删、改 功能。</b><br />后续如果增加新的权限或者删改老的权限，可以使用SQL脚本来实现。</p>
                  </div>
                </div><!-- /.box-header -->
                <div class="box-body table-responsive">
                      <div class="form-group">
                        <div class="input-group">
                          <?php foreach($permissions as $index => $per): ?>
                            <?php if(starts_with($per->name, '@') && $index !== 0): ?>
                            <br>
                            <?php endif; ?>
                            <label class="choice" title="<?php echo e($per->id); ?> : <?php echo e($per->name); ?> [<?php echo e($per->display_name); ?>]" style="width: 250px; text-align: center; border: 1px dotted #333; margin-right: 1px;"><span class="text-green"><?php echo e($per->name); ?></span>[<span class="text-red"><?php echo e($per->display_name); ?></span>]</label>
                          <?php endforeach; ?>
                        </div>
                      </div>
                </div><!-- /.box-body -->
              </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layout._back', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>