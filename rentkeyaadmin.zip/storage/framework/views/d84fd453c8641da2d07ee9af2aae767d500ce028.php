<?php $__env->startSection('content-header'); ?>
@parent
          <h1>
            控制面板
            <small>概述</small>
          </h1>
          <ol class="breadcrumb">
            <li><a href="<?php echo e(site_url('dashboard', 'admin')); ?>"><i class="fa fa-dashboard"></i> 主页</a></li>
            <li class="active">控制面板 - 概述</li>
          </ol>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout._back', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>