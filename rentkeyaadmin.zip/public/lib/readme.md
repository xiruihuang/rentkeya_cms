# Readme for douyasi public lib files

### Bootstrap

Official website: http://getbootstrap.com/

Github source: https://github.com/twbs/bootstrap

### Chosen

Official website: https://harvesthq.github.io/chosen/

Github source: https://github.com/harvesthq/chosen

### CKEidtor

Official website: http://ckeditor.com/

### Font Awesome

Official website: http://fontawesome.io/

Github source: https://github.com/FortAwesome/Font-Awesome

### jQuery Form Plugin

Official website: http://malsup.com/jquery/form/

Github source: https://github.com/malsup/form

### The HTML5 Shiv

GitHub source: https://github.com/aFarkas/html5shiv/

### iCheck

Official website: http://icheck.fronteed.com/

Github source: https://github.com/fronteed/iCheck

### Ionicons

Official website: http://ionicons.com/

GitHub source: https://github.com/driftyco/ionicons

### jQuery

Official website: http://jquery.com/

Github source: https://github.com/jquery/jquery

### layer

Official website: http://layer.layui.com/

Github source: https://github.com/sentsin/layer

### Respond.js

Github source: https://github.com/scottjehl/Respond

### Google Webfonts

Official website: https://www.google.com/fonts/

Website for self-host webfonts: https://google-webfonts-helper.herokuapp.com/


