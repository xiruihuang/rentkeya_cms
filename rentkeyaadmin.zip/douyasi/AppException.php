<?php

namespace Douyasi;

/**
 * Class AppException
 *
 * 应用相关异常类
 *
 * @package Qucheng
 * @author raoyc <raoyc2009@gmail.com>
 */
class AppException extends \Exception
{
    
}
