{{-- 分页样式 --}}
{{ with(new Douyasi\Extensions\SimpleBootstrapThreePreviousNextPresenter($paginator))->render() }}
